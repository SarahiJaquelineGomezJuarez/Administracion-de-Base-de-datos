SELECT TOP (1000) [ID_Empleado]
      ,[Nombre]
      ,[Direccion]
      ,[Numero_Telefono]
      ,[Fecha_de_Nacimiento]
      ,[Edad]
      ,[Correo_Electronico_Empleado]
      ,[Contrasena]
      ,[ID_Sucursal]
  FROM [AkirasBoutiques].[dbo].[Empleados]
  ----------------Insertar datos en la Tabla Empleado--------------------
  USE AkirasBoutiques;
GO

-- Insertar datos en la tabla Empleados
INSERT INTO Empleados (ID_Empleado, Nombre, Direccion, Numero_Telefono, Fecha_de_Nacimiento, Correo_Electronico_Empleado, Contrasena, ID_Sucursal)
VALUES 
-- Empleados para la Sucursal 1
(1, 'Juan P�rez', 'Calle Principal #123', '444 123 4567', '1990-01-15', 'juan.perez@example.com', 'password123', 1),
(2, 'Ana Garc�a', 'Calle Secundaria #456', '444 765 4321', '1985-05-20', 'ana.garcia@example.com', 'securepass', 1),

-- Empleados para la Sucursal 2
(3, 'Carlos Mendoza', 'Calle Tercera #789', '449 456 7890', '1988-09-10', 'carlos.mendoza@example.com', 'mypassword', 2),
(4, 'Laura S�nchez', 'Calle Cuarta #321', '449 654 0987', '1992-02-25', 'laura.sanchez@example.com', 'pass1234', 2),

-- Empleados para la Sucursal 3
(5, 'Pedro Jim�nez', 'Av. Quinta #654', '669 789 0123', '1995-07-18', 'pedro.jimenez@example.com', 'secure123', 3),
(6, 'Marta L�pez', 'Av. Sexta #987', '669 321 0987', '1987-11-30', 'marta.lopez@example.com', 'mypassword123', 3),

-- Empleados para la Sucursal 4
(7, 'Luis Fern�ndez', 'Calle S�ptima #111', '333 444 5555', '1991-03-05', 'luis.fernandez@example.com', 'mysecurepass', 4),
(8, 'Sara Mart�nez', 'Calle Octava #222', '333 666 7777', '1993-06-22', 'sara.martinez@example.com', 'password456', 4),

-- Empleados para la Sucursal 5
(9, 'Jos� G�mez', 'Av. Novena #333', '614 888 9999', '1994-12-01', 'jose.gomez@example.com', 'mypassword456', 5),
(10, 'Rosa Ortega', 'Av. D�cima #444', '614 111 2222', '1986-04-14', 'rosa.ortega@example.com', 'secure789', 5),

-- Empleados para la Sucursal 6
(11, 'Miguel Torres', 'Calle Once #555', '618 333 4444', '1990-08-08', 'miguel.torres@example.com', 'mypassword789', 6),
(12, 'Luc�a Ruiz', 'Calle Doce #666', '618 555 6666', '1989-03-03', 'lucia.ruiz@example.com', 'pass789', 6),

-- Empleados para la Sucursal 7
(13, 'Alberto Vega', 'Av. Trece #777', '492 777 8888', '1988-05-25', 'alberto.vega@example.com', 'mypassword999', 7),
(14, 'Mar�a Hern�ndez', 'Av. Catorce #888', '492 999 0000', '1992-09-12', 'maria.hernandez@example.com', 'secure1234', 7);
GO
USE AkirasBoutiques;
GO

SELECT TOP (1000) 
    [ID_Empleado],
    [Nombre],
    [Direccion],
    [Numero_Telefono],
    [Fecha_de_Nacimiento],
    [Edad],
    [Correo_Electronico_Empleado],
    [Contrasena],
    [ID_Sucursal]
FROM [dbo].[Empleados];
GO
-----Insertar 40 Datos mas a la tabla Empleado-----
USE AkirasBoutiques;
GO

INSERT INTO Empleados (ID_Empleado, Nombre, Direccion, Numero_Telefono, Fecha_de_Nacimiento, Correo_Electronico_Empleado, Contrasena, ID_Sucursal)
VALUES 
-- Empleados para la Sucursal 1 (total 8 empleados)
(15, 'Jorge N��ez', 'Calle Primavera #789', '444 555 6677', '1987-04-15', 'jorge.nunez@example.com', 'pass12345', 1),
(16, 'Laura Silva', 'Calle Manzana #101', '444 222 3334', '1991-07-25', 'laura.silva@example.com', 'password321', 1),

-- Empleados para la Sucursal 2 (total 8 empleados)
(17, 'Andr�s L�pez', 'Calle Lim�n #102', '449 876 5432', '1985-11-18', 'andres.lopez@example.com', 'secure456', 2),
(18, 'Claudia P�rez', 'Calle Durazno #789', '449 987 6543', '1992-12-22', 'claudia.perez@example.com', 'mypassword1234', 2),

-- Empleados para la Sucursal 3 (total 8 empleados)
(19, 'Francisco Ram�rez', 'Av. Palmera #303', '669 654 1234', '1989-02-17', 'francisco.ramirez@example.com', 'password789', 3),
(20, 'Susana D�az', 'Av. Mango #404', '669 765 4321', '1993-06-19', 'susana.diaz@example.com', 'secure987', 3),

-- Empleados para la Sucursal 4 (total 8 empleados)
(21, 'Ricardo Castillo', 'Calle Lim�n #505', '333 123 4567', '1988-08-12', 'ricardo.castillo@example.com', 'pass1111', 4),
(22, 'Mariana Ortiz', 'Calle Mora #606', '333 234 5678', '1990-01-23', 'mariana.ortiz@example.com', 'mypassword567', 4),

-- Empleados para la Sucursal 5 (total 8 empleados)
(23, 'Carmen Morales', 'Av. Sand�a #707', '614 345 6789', '1987-03-29', 'carmen.morales@example.com', 'secure222', 5),
(24, 'H�ctor Pe�a', 'Av. Uva #808', '614 456 7890', '1989-11-05', 'hector.pena@example.com', 'pass333', 5),

-- Empleados para la Sucursal 6 (total 8 empleados)
(25, 'Esteban Cruz', 'Calle Nuez #909', '618 567 8901', '1991-04-04', 'esteban.cruz@example.com', 'password444', 6),
(26, 'Paola G�mez', 'Calle Pera #1010', '618 678 9012', '1994-09-30', 'paola.gomez@example.com', 'secure555', 6),

-- Empleados para la Sucursal 7 (total 8 empleados)
(27, 'Fernando Vel�zquez', 'Av. Fresa #1111', '492 789 0123', '1990-10-15', 'fernando.velazquez@example.com', 'pass666', 7),
(28, 'Valeria Su�rez', 'Av. Coco #1212', '492 890 1234', '1988-06-25', 'valeria.suarez@example.com', 'mypassword888', 7),
-- Empleados adicionales para la Sucursal 1
(29, 'Natalia Flores', 'Calle Naranja #111', '444 345 6789', '1992-12-01', 'natalia.flores@example.com', 'pass7890', 1),
(30, 'Pablo Cort�s', 'Calle Fresa #121', '444 456 7890', '1985-07-07', 'pablo.cortes@example.com', 'secure2020', 1),

-- Empleados adicionales para la Sucursal 2
(31, 'Diego M�ndez', 'Av. Coco #222', '449 567 8901', '1993-03-03', 'diego.mendez@example.com', 'password1414', 2),
(32, 'Gabriela Herrera', 'Av. Lima #333', '449 678 9012', '1989-11-19', 'gabriela.herrera@example.com', 'secure1515', 2),

-- Empleados adicionales para la Sucursal 3
(33, 'Rafael Salinas', 'Calle Fresa #444', '669 789 0123', '1987-02-14', 'rafael.salinas@example.com', 'mypassword1616', 3),
(34, 'Lorena Castro', 'Calle Lima #555', '669 890 1234', '1991-08-09', 'lorena.castro@example.com', 'password1717', 3),

-- Empleados adicionales para la Sucursal 4
(35, 'Adriana L�pez', 'Calle Uva #666', '333 901 2345', '1986-09-22', 'adriana.lopez@example.com', 'secure1818', 4),
(36, 'Mauricio Medina', 'Av. Sand�a #777', '333 012 3456', '1989-04-02', 'mauricio.medina@example.com', 'mypassword1919', 4),

-- Empleados adicionales para la Sucursal 5
(37, 'Patricia Navarro', 'Calle Mora #888', '614 123 4567', '1988-05-11', 'patricia.navarro@example.com', 'pass2020', 5),
(38, 'Roberto Rojas', 'Av. Mel�n #999', '614 234 5678', '1992-07-23', 'roberto.rojas@example.com', 'secure2121', 5),

-- Empleados adicionales para la Sucursal 6
(39, 'Ver�nica Reyes', 'Calle Manzana #1010', '618 345 6789', '1993-09-30', 'veronica.reyes@example.com', 'mypassword2222', 6),
(40, 'Sergio Navarro', 'Calle Mel�n #1111', '618 456 7890', '1987-11-05', 'sergio.navarro@example.com', 'password2323', 6),

-- Empleados adicionales para la Sucursal 7
(41, 'Alejandra Dom�nguez', 'Calle Pl�tano #1212', '492 567 8901', '1986-08-15', 'alejandra.dominguez@example.com', 'secure2424', 7),
(42, 'Tom�s Ortega', 'Av. Uva #1313', '492 678 9012', '1990-12-19', 'tomas.ortega@example.com', 'mypassword2525', 7),

-- M�s empleados para las Sucursales para llegar a 54
-- Sucursal 1
(43, 'Eduardo Ramos', 'Calle Nuez #1414', '444 567 8901', '1991-05-10', 'eduardo.ramos@example.com', 'password2626', 1),

-- Sucursal 2
(44, 'Natalia Gonz�lez', 'Av. Sand�a #1515', '449 123 4567', '1988-09-07', 'natalia.gonzalez@example.com', 'secure2727', 2),

-- Sucursal 3
(45, 'Mario Valle', 'Calle Mel�n #1616', '669 345 6789', '1987-06-21', 'mario.valle@example.com', 'mypassword2828', 3),

-- Sucursal 4
(46, 'Elena Vargas', 'Av. Mora #1717', '333 567 8901', '1990-11-29', 'elena.vargas@example.com', 'password2929', 4),

-- Sucursal 5
(47, 'Ignacio Ram�rez', 'Calle Fresa #1818', '614 234 5678', '1992-01-12', 'ignacio.ramirez@example.com', 'secure3030', 5),

-- Sucursal 6
(48, 'Adela Torres', 'Av. Pl�tano #1919', '618 678 9012', '1989-02-02', 'adela.torres@example.com', 'mypassword3131', 6),

-- Sucursal 7
(49, 'Carlos Mar�n', 'Calle Sand�a #2020', '492 789 0123', '1985-10-25', 'carlos.marin@example.com', 'password3232', 7),

-- �ltimos empleados para alcanzar 54
-- Sucursal 1
(50, 'Isabel Ponce', 'Av. Manzana #2121', '444 890 1234', '1993-03-11', 'isabel.ponce@example.com', 'secure3333', 1),

-- Sucursal 2
(51, 'Estefan�a Salazar', 'Calle Mora #2222', '449 901 2345', '1986-06-17', 'estefania.salazar@example.com', 'mypassword3434', 2),

-- Sucursal 3
(52, 'David Castro', 'Av. Mel�n #2323', '669 012 3456', '1994-07-01', 'david.castro@example.com', 'password3535', 3),

-- Sucursal 4
(53, 'Alicia Luna', 'Calle Nuez #2424', '333 123 4567', '1989-05-15', 'alicia.luna@example.com', 'secure3636', 4),

-- Sucursal 5
(54, 'Gabriel S�nchez', 'Av. Mora #2525', '614 234 5678', '1990-09-08', 'gabriel.sanchez@example.com', 'mypassword3737', 5);
GO
SELECT TOP (1000) [ID_Empleado]
      ,[Nombre]
      ,[Direccion]
      ,[Numero_Telefono]
      ,[Fecha_de_Nacimiento]
      ,[Edad]
      ,[Correo_Electronico_Empleado]
      ,[Contrasena]
      ,[ID_Sucursal]
  FROM [AkirasBoutiques].[dbo].[Empleados]
  ------Consulta por Sucursal----
  USE AkirasBoutiques;
GO

SELECT 
    [ID_Empleado],
    [Nombre],
    [Direccion],
    [Numero_Telefono],
    [Fecha_de_Nacimiento],
    [Edad],
    [Correo_Electronico_Empleado],
    [Contrasena],
    [ID_Sucursal]
FROM [dbo].[Empleados]
WHERE [ID_Sucursal] = 5
GO
--------Sucursal 4-----
  USE AkirasBoutiques;
GO

SELECT 
    [ID_Empleado],
    [Nombre],
    [Direccion],
    [Numero_Telefono],
    [Fecha_de_Nacimiento],
    [Edad],
    [Correo_Electronico_Empleado],
    [Contrasena],
    [ID_Sucursal]
FROM [dbo].[Empleados]
WHERE [ID_Sucursal] = 4
GO
-----------Sucursal 3-------
  USE AkirasBoutiques;
GO

SELECT 
    [ID_Empleado],
    [Nombre],
    [Direccion],
    [Numero_Telefono],
    [Fecha_de_Nacimiento],
    [Edad],
    [Correo_Electronico_Empleado],
    [Contrasena],
    [ID_Sucursal]
FROM [dbo].[Empleados]
WHERE [ID_Sucursal] = 3
GO
-------Sucursal 2-----------------
  USE AkirasBoutiques;
GO
SELECT 
    [ID_Empleado],
    [Nombre],
    [Direccion],
    [Numero_Telefono],
    [Fecha_de_Nacimiento],
    [Edad],
    [Correo_Electronico_Empleado],
    [Contrasena],
    [ID_Sucursal]
FROM [dbo].[Empleados]
WHERE [ID_Sucursal] = 2
GO
---------------------Obtener las sucursales y contar cu�ntos empleados tiene cada una------
  USE AkirasBoutiques;
GO
SELECT 
    S.Nombre_Sucursal,
    COUNT(E.ID_Empleado) AS Numero_De_Empleados
FROM [dbo].[Sucursales] S
LEFT JOIN [dbo].[Empleados] E ON S.ID_Sucursal = E.ID_Sucursal
GROUP BY S.Nombre_Sucursal;
GO

-------Obtener los detalles de las sucursales junto con la informaci�n de los empleados que pertenecen a ellas---
 USE AkirasBoutiques;
GO
SELECT 
    S.Nombre_Sucursal,
    S.Encargado_Sucursal,
    E.Nombre AS Nombre_Empleado,
    E.Numero_Telefono,
    E.Correo_Electronico_Empleado
FROM [dbo].[Sucursales] S
INNER JOIN [dbo].[Empleados] E ON S.ID_Sucursal = E.ID_Sucursal
ORDER BY S.Nombre_Sucursal;
GO
------Obtener el nombre del encargado por sucursal-------------------------------------------
USE AkirasBoutiques;
GO
SELECT 
    S.ID_Sucursal,
    S.Nombre_Sucursal,
    E.ID_Empleado,
    E.Nombre AS Encargado
FROM [dbo].[Sucursales] S
INNER JOIN [dbo].[Empleados] E ON S.ID_Sucursal = E.ID_Sucursal
WHERE E.ID_Empleado IN (1, 3, 5, 7, 9, 11, 13); -- Suponemos que estos IDs son los encargados
GO
-----------------Calcular Fecha_de_Nacimiento en la tabla Empleados y calcular su edad en la consulta.-------------
USE AkirasBoutiques;
GO

SELECT 
    [ID_Empleado],
    [Nombre],
    [Direccion],
    [Numero_Telefono],
    [Fecha_de_Nacimiento],
    [Edad],
    [Correo_Electronico_Empleado],
    [Contrasena],
    [ID_Sucursal]
FROM [dbo].[Empleados]
WHERE DATEDIFF(YEAR, [Fecha_de_Nacimiento], GETDATE()) - 
      CASE 
          WHEN MONTH([Fecha_de_Nacimiento]) > MONTH(GETDATE()) OR 
               (MONTH([Fecha_de_Nacimiento]) = MONTH(GETDATE()) AND DAY([Fecha_de_Nacimiento]) > DAY(GETDATE())) 
          THEN 1 
          ELSE 0 
      END = 30
GO






